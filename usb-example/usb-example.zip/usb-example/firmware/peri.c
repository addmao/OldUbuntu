#include <avr/io.h>
#include "peri.h"

void init_peripheral()
{
    // วางโค้ดจาก elab
}

void set_led(uint8_t pin, uint8_t state)
{
    // วางโค้ดจาก elab
}

void set_led_value(uint8_t value)
{
    // วางโค้ดจาก elab
}

uint16_t read_adc(uint8_t channel)
{
    // วางโค้ดจากสไลด์บรรยาย
}

uint16_t get_light()
{
    // วางโค้ดจาก elab
}
